module.exports = {
  secret: 'Geekboots Love ShoeSystem',
};