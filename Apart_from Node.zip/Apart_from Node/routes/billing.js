const express = require('express');
const router = express.Router();
const fs = require("fs");
const pdfParse = require("pdf-parse");
const db = require('../module/dbConnect');
const midWare = require('../module/middleware');
const PDF2Pic = require("pdf2pic");


router.get('/api/bill/upload', (req, res, next) => {
    let pdfData = {};
    pdfData.filePath = "Medical_1573821016472_9845496618.pdf";
    fs.readFile("./public/pdfBills/"+pdfData.filePath, (err, pdfBuffer) => {
        pdfParse(pdfBuffer).then((data) => {
            //console.log(data);
            
            const splitText = data.text.split(/\r?\n/);
            
            pdfData.raw = data.text;
            pdfData.reports = [];
            let isParsingComplete = false;

            for (let itr = 0; itr < splitText.length; itr++) {
                let lineData = splitText[itr].trim();
                const dateFormat = /^(((0)[0-9])|((1)[0-2]))(\-)([0-2][0-9]|(3)[0-1])(\-)\d{4}$/;

                if (!pdfData.title && lineData.length > 0) {
                    pdfData.title = lineData;
                } else if (!pdfData.customer && lineData.indexOf("Customer:") >= 0) {
                    pdfData.customer = lineData
                    .substring(lineData.indexOf("Customer:") + "Customer:".length)
                    .trim();
                    continue;
                } else if (!pdfData.seller && lineData.indexOf("Seller:") >= 0) {
                    pdfData.seller = lineData
                    .substring(lineData.indexOf("Seller:") + "Seller:".length)
                    .trim();
                    itr++;
                    pdfData.subTitle = splitText[itr].trim();
                    continue;
                } else if (!pdfData.transaction && lineData.indexOf("Transaction") >= 0) {
                    pdfData.transaction = lineData
                    .substring(lineData.indexOf("Transaction") + "Transaction".length)
                    .trim();
                    continue;
                } else if (!pdfData.date && lineData.match(dateFormat)) {
                    pdfData.date = lineData;
                    itr++;
                    pdfData.time = splitText[itr].trim();
                    continue;
                    // 8377 is ascii code of rupee symbol
                } else if (
                    lineData.length > 0 &&
                    lineData[0] === String.fromCharCode(8377) &&
                    splitText[itr + 1] &&
                    splitText[itr + 1].indexOf(" X") > 0
                ) {
                    let amount = lineData.substring(1).trim();
                    //amount = amount.replace(/\,/g, "");
                    itr++;
                    lineData = splitText[itr].trim();
                    let description = lineData.substring(lineData.indexOf(" ") + 2).trim();
                    let qty = lineData.substring(0, lineData.indexOf(" ")).trim();
                    pdfData.reports.push({
                        description: description,
                        qty: qty,
                        amount: amount
                    });
                    continue;
                } else if (!pdfData.total && lineData.indexOf("Total:") >= 0) {
                    let total = lineData
                    .substring(lineData.indexOf("Total:") + "Total:".length + 1)
                    .trim();
                    //total = total.replace(/\,/g, "");
                    pdfData.total = total;
                    isParsingComplete = true;
                    continue;
                }
            }

            //console.log(pdfData.total.replace(/[^a-zA-Z0-9]/g, ''));

            let pDate = pdfData.customer.split('-');
            //console.log(pDate[2]+"-"+pDate[1]+"-"+pDate[0]);
            
            pdfData.date = new Date(pDate[2]+"-"+pDate[0]+"-"+pDate[1]);



            let fNData = pdfData.filePath.split('_');
            let usrMobile = fNData[2].split('.');
            pdfData.deportment = fNData[0];
            pdfData.user = usrMobile[0];
            //pdfData.date = new Date(fNData[1] * 1000);
            pdfData.genDate = new Date(fNData[1]*1000).toString();
             
            
            // var pdfImage = new PDFImage("./public/pdfBills/"+pdfData.filePath);
            // pdfImage.convertPage().then((imgPath) => {
            //     console.log(imgPath);
            // });

            const pdf2pic = new PDF2Pic({
                density: 100,
                savename: pdfData.filePath,
                savedir: "./public/pdfBills/images",
                format: "jpg",
                size: "900x800"
            });

            console.log(pdfData);
            
                
            pdf2pic.convertBulk("./public/pdfBills/"+pdfData.filePath, -1).then((resolve) => {
                pdfData.billImg = resolve;
                db.getDB().collection('billing').insertOne(pdfData, (err, doc) => {
                    if(err) {
                        res.status(410).jsonp(err);
                        next(err);

                    } else {
                        res.status(201).jsonp('Bill added successfully!');
                    }
                });
            });

            //res.status(201).jsonp('Bill added successfully!');
            
            // db.getDB().collection('billing').insertOne(pdfData, (err, doc) => {
            //     if(err) {
            //         res.status(410).jsonp(err);
            //         next(err);

            //     } else {
            //         res.status(201).jsonp('Bill added successfully!');
            //     }
            // });
        });
    });
});


router.get('/api/bill/:month/:year', midWare.checkToken, (req, res, next) => {
   db.getDB().collection('billing').find({user: req.decoded.mobile, date: {$gte: new Date(req.params.year+"-"+req.params.month+"-01"), $lt: new Date()}}).toArray((err, doc) => {
   // db.getDB().collection('billing').find({date: {$gte: new Date(req.params.year+"-"+req.params.month+"-01"), $lt: new Date()}}).toArray((err, doc) => {
        if(err) {
            res.status(410).jsonp(err);
            next(err);
        } else {
            //console.log(doc);
            res.status(200).jsonp(doc);
        }
    });
});


module.exports = router;
